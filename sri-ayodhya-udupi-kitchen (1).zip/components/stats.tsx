'use client'

import { motion } from 'framer-motion'
import { CountUp } from './count-up'

const stats = [
  {
    value: 12,
    suffix: '+',
    label: 'Years of Excellence',
    description: 'Serving authentic cuisine since 2012',
  },
  {
    value: 837,
    suffix: '+',
    label: 'Customer Reviews',
    description: '4.3 star average rating',
  },
  {
    value: 45,
    suffix: '',
    label: 'Signature Dishes',
    description: 'Curated menu of specialties',
  },
  {
    value: 120,
    suffix: '+',
    label: 'Seats',
    description: 'Elegant dining capacity',
  },
]

export function Stats() {
  return (
    <section className="py-20 px-4 sm:px-8 bg-secondary/50">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-2">By The Numbers</p>
          <h2 className="font-serif text-4xl sm:text-5xl font-bold">Our Legacy</h2>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mb-4">
                <span className="font-serif text-5xl font-bold text-primary">
                  <CountUp to={stat.value} />
                </span>
                <span className="text-3xl text-primary font-bold">{stat.suffix}</span>
              </div>
              <h3 className="font-semibold text-foreground mb-2">{stat.label}</h3>
              <p className="text-sm text-muted-foreground">{stat.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
