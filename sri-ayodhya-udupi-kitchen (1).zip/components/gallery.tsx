'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'
import { X } from 'lucide-react'

const images = [
  { id: 1, alt: 'Masala Dosa - Crispy rice crepe with spiced potato filling', color: 'from-orange-900 to-yellow-900' },
  { id: 2, alt: 'Restaurant interior - Elegant dining with gold accents', color: 'from-amber-900 to-yellow-800' },
  { id: 3, alt: 'Thali - Complete vegetarian feast platter', color: 'from-red-900 to-orange-900' },
  { id: 4, alt: 'Paneer Tikka Masala - Creamy cottage cheese curry', color: 'from-orange-800 to-amber-900' },
  { id: 5, alt: 'Traditional South Indian lunch setting', color: 'from-yellow-900 to-orange-900' },
  { id: 6, alt: 'Dessert selection - Gulab Jamun, Kheer, and Payasam', color: 'from-amber-800 to-yellow-900' },
]

export function Gallery() {
  const [selectedId, setSelectedId] = useState<number | null>(null)

  return (
    <section id="gallery" className="py-20 px-4 sm:px-8 bg-secondary/30">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="max-w-6xl mx-auto mb-16"
      >
        <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-2">Visual Experience</p>
        <h2 className="font-serif text-4xl sm:text-5xl font-bold mb-4">Gallery Moments</h2>
        <p className="text-muted-foreground max-w-2xl">
          Witness the culinary artistry and ambiance that defines Sri Ayodhya Udupi Kitchen.
        </p>
      </motion.div>

      {/* Gallery Grid */}
      <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
        {images.map((image, index) => (
          <motion.div
            key={image.id}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            viewport={{ once: true }}
            onClick={() => setSelectedId(image.id)}
            className={`relative aspect-square rounded-lg overflow-hidden cursor-pointer group bg-gradient-to-br ${image.color}`}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-primary/20 to-black/40 group-hover:from-primary/40 group-hover:to-black/60 transition-all duration-300 z-10" />
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20" />
            <div className="absolute inset-0 flex items-center justify-center text-center z-30 p-4">
              <p className="text-foreground font-serif text-lg font-semibold text-balance">{image.alt}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Lightbox */}
      {selectedId && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedId(null)}
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.8 }}
            onClick={(e) => e.stopPropagation()}
            className={`relative w-full max-w-2xl aspect-square rounded-lg bg-gradient-to-br ${images.find(i => i.id === selectedId)?.color}`}
          >
            <button
              onClick={() => setSelectedId(null)}
              className="absolute -top-10 right-0 text-foreground hover:text-primary transition-colors"
            >
              <X size={32} />
            </button>
            <div className="w-full h-full flex items-center justify-center text-center p-8">
              <p className="text-foreground font-serif text-2xl font-semibold text-balance">
                {images.find(i => i.id === selectedId)?.alt}
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </section>
  )
}
