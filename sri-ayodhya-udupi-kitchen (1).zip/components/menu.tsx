'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'

interface MenuItem {
  name: string
  description: string
  price: string
  icon: string
}

const categories: Record<string, MenuItem[]> = {
  'South Indian': [
    {
      name: 'Masala Dosa',
      description: 'Crispy rice crepe filled with spiced potatoes and onions, served with sambar and chutney',
      price: '₹250',
      icon: '🥘',
    },
    {
      name: 'Idli Sambar',
      description: 'Steamed rice cakes served with tangy lentil vegetable stew',
      price: '₹180',
      icon: '🍲',
    },
    {
      name: 'Uttapam',
      description: 'Thick rice pancake topped with onions, tomatoes and herbs',
      price: '₹220',
      icon: '🥞',
    },
    {
      name: 'Vada',
      description: 'Crispy lentil fritters served with sambar and chutney',
      price: '₹120',
      icon: '🍤',
    },
  ],
  'North Indian': [
    {
      name: 'Paneer Tikka Masala',
      description: 'Tender cottage cheese in creamy tomato and cream sauce',
      price: '₹380',
      icon: '🧀',
    },
    {
      name: 'Chana Masala',
      description: 'Chickpeas in aromatic spiced gravy, served with rice',
      price: '₹280',
      icon: '🌾',
    },
    {
      name: 'Naan Varieties',
      description: 'Freshly baked Indian breads: Plain, Garlic, Butter, Paneer',
      price: '₹80-120',
      icon: '🍞',
    },
    {
      name: 'Dal Makhani',
      description: 'Black lentils slow-cooked in butter and cream',
      price: '₹300',
      icon: '🫘',
    },
  ],
  'Desserts': [
    {
      name: 'Gulab Jamun',
      description: 'Soft milk solids in aromatic sugar syrup',
      price: '₹150',
      icon: '🍶',
    },
    {
      name: 'Kheer',
      description: 'Creamy rice pudding with cardamom and nuts',
      price: '₹120',
      icon: '🍯',
    },
    {
      name: 'Jalebi',
      description: 'Crispy spirals soaked in sugar syrup',
      price: '₹100',
      icon: '🧁',
    },
    {
      name: 'Payasam',
      description: 'Traditional South Indian sweet with vermicelli and jaggery',
      price: '₹140',
      icon: '🍮',
    },
  ],
  'Beverages': [
    {
      name: 'Masala Chai',
      description: 'Aromatic tea spiced with ginger, cardamom, and cloves',
      price: '₹60',
      icon: '☕',
    },
    {
      name: 'Mango Lassi',
      description: 'Refreshing yogurt-based mango drink',
      price: '₹120',
      icon: '🥤',
    },
    {
      name: 'Fresh Coconut Water',
      description: 'Pure, fresh coconut water',
      price: '₹80',
      icon: '🥥',
    },
    {
      name: 'Filter Coffee',
      description: 'Traditional South Indian filter coffee',
      price: '₹70',
      icon: '☕',
    },
  ],
}

export function Menu() {
  const [activeCategory, setActiveCategory] = useState('South Indian')

  return (
    <section id="menu" className="py-20 px-4 sm:px-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mb-16"
      >
        <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-2">Our Culinary</p>
        <h2 className="font-serif text-4xl sm:text-5xl font-bold mb-4">Authentic Flavors</h2>
        <p className="text-muted-foreground max-w-2xl">
          Discover our carefully curated selection of traditional South Indian and North Indian vegetarian dishes, each prepared with premium ingredients and time-honored techniques.
        </p>
      </motion.div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2 sm:gap-4 mb-12 overflow-x-auto pb-2">
        {Object.keys(categories).map((category) => (
          <motion.button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-6 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
              activeCategory === category
                ? 'bg-primary text-primary-foreground'
                : 'glass text-foreground hover:bg-white/15'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {category}
          </motion.button>
        ))}
      </div>

      {/* Menu Items */}
      <motion.div
        key={activeCategory}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="grid md:grid-cols-2 gap-6"
      >
        {categories[activeCategory]?.map((item, index) => (
          <motion.div
            key={item.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="glass p-6 rounded-xl hover:bg-white/15 transition-colors group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{item.icon}</span>
                <div>
                  <h3 className="font-serif font-bold text-lg text-foreground">{item.name}</h3>
                  <p className="text-primary text-sm font-semibold">{item.price}</p>
                </div>
              </div>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
          </motion.div>
        ))}
      </motion.div>
    </section>
  )
}
