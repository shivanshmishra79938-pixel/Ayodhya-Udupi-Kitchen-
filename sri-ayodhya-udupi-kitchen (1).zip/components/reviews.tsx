'use client'

import { motion } from 'framer-motion'

interface Review {
  author: string
  rating: number
  text: string
  date: string
}

const reviews: Review[] = [
  {
    author: 'Priya Sharma',
    rating: 5,
    text: 'Absolutely divine! The Masala Dosa was perfection - crispy on the outside, perfectly spiced inside. The atmosphere is so elegant and the service impeccable. Worth every rupee!',
    date: '2 weeks ago',
  },
  {
    author: 'Rajesh Kumar',
    rating: 5,
    text: 'Been coming here for 5 years and never disappointed. The quality is consistent, the food is authentic, and the hospitality is world-class. Best vegetarian restaurant in the city!',
    date: '1 month ago',
  },
  {
    author: 'Ananya Patel',
    rating: 4,
    text: 'Loved the Paneer Tikka Masala and the ambiance was fantastic. Only minor point - the wait time during peak hours, but honestly it\'s worth it. Highly recommended!',
    date: '3 weeks ago',
  },
  {
    author: 'Vikram Singh',
    rating: 5,
    text: 'Exceptional culinary experience. Each dish tells a story of tradition and quality. The Payasam is legendary - I\'ve tried making it at home but nothing compares!',
    date: '1 week ago',
  },
]

export function Reviews() {
  return (
    <section id="reviews" className="py-20 px-4 sm:px-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mb-16"
      >
        <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-2">Guest Experiences</p>
        <h2 className="font-serif text-4xl sm:text-5xl font-bold mb-4">Loved by Our Guests</h2>
        <p className="text-muted-foreground max-w-2xl">
          Read what our satisfied customers say about their dining experiences at Sri Ayodhya Udupi Kitchen.
        </p>
      </motion.div>

      {/* Reviews Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {reviews.map((review, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-xl"
          >
            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <span key={i} className={i < review.rating ? 'text-primary text-xl' : 'text-muted text-xl'}>
                  ★
                </span>
              ))}
            </div>

            {/* Review Text */}
            <p className="text-foreground mb-6 leading-relaxed italic">{`"${review.text}"`}</p>

            {/* Author */}
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-foreground">{review.author}</p>
                <p className="text-xs text-muted-foreground">{review.date}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/50 rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold">{review.author[0]}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Overall Rating Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        viewport={{ once: true }}
        className="mt-12 glass p-8 rounded-xl text-center"
      >
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="flex gap-1">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="text-primary text-3xl">
                ★
              </span>
            ))}
          </div>
          <span className="font-serif text-4xl font-bold text-primary">4.3</span>
        </div>
        <p className="text-muted-foreground mb-2">Based on 837+ verified reviews</p>
        <p className="text-foreground font-semibold">Google Reviews • TripAdvisor • Zomato • Swiggy</p>
      </motion.div>
    </section>
  )
}
