'use client'

import { motion } from 'framer-motion'
import { Heart, Share2, Mail } from 'lucide-react'

export function Footer() {
  const socialLinks = [
    { icon: Share2, href: 'https://twitter.com', label: 'Social' },
    { icon: Mail, href: 'mailto:hello@sriayodhya.com', label: 'Contact' },
  ]

  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-secondary/50 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-serif font-bold">अ</span>
              </div>
              <h3 className="font-serif text-lg font-bold text-foreground">Sri Ayodhya</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Authentic South Indian and North Indian vegetarian cuisine since 2012.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-foreground mb-4">Quick Links</h4>
            <nav className="space-y-2">
              {['Menu', 'Gallery', 'Reviews', 'Location', 'Contact'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="text-sm text-muted-foreground hover:text-primary transition-colors block"
                >
                  {link}
                </a>
              ))}
            </nav>
          </motion.div>

          {/* Hours */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-foreground mb-4">Hours</h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Mon-Thu: 11 AM - 10 PM</p>
              <p>Fri-Sat: 11 AM - 11 PM</p>
              <p>Sunday: 12 PM - 10 PM</p>
            </div>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-foreground mb-4">Contact</h4>
            <div className="text-sm text-muted-foreground space-y-2">
              <a href="tel:+918041234567" className="hover:text-primary transition-colors block">
                +91 8041234567
              </a>
              <a href="mailto:hello@sriayodhya.com" className="hover:text-primary transition-colors block">
                hello@sriayodhya.com
              </a>
            </div>
          </motion.div>
        </div>

        {/* Divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="h-px bg-border mb-8 origin-left"
        />

        {/* Bottom */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="flex flex-col sm:flex-row items-center justify-between gap-4"
        >
          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            © {currentYear} Sri Ayodhya Udupi Kitchen. All rights reserved.
          </p>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => (
              <motion.a
                key={social.label}
                href={social.href}
                whileHover={{ scale: 1.2, color: '#d4af37' }}
                className="text-muted-foreground hover:text-primary transition-colors"
                aria-label={social.label}
              >
                <social.icon size={20} />
              </motion.a>
            ))}
          </div>

          {/* Made with love */}
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            Made with <Heart size={16} className="text-primary fill-primary" /> for food lovers
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
