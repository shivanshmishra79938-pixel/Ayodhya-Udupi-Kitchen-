'use client'

import { useEffect, useRef, useState } from 'react'

interface CountUpProps {
  to: number
  duration?: number
}

export function CountUp({ to, duration = 2 }: CountUpProps) {
  const [count, setCount] = useState(0)
  const hasStarted = useRef(false)
  const containerRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted.current) {
          hasStarted.current = true
          const start = Date.now()
          const interval = setInterval(() => {
            const elapsed = Date.now() - start
            const progress = Math.min(elapsed / (duration * 1000), 1)
            setCount(Math.floor(progress * to))
            if (progress === 1) clearInterval(interval)
          }, 16)
        }
      },
      { threshold: 0.1 }
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => {
      if (containerRef.current) observer.unobserve(containerRef.current)
    }
  }, [to, duration])

  return <span ref={containerRef}>{count}</span>
}
