'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Phone, Mail, MessageCircle, X } from 'lucide-react'
import { useState } from 'react'

export function FloatingCTA() {
  const [isOpen, setIsOpen] = useState(false)

  const actions = [
    { icon: Phone, label: 'Call', href: 'tel:+918041234567', color: 'from-blue-500 to-blue-600' },
    { icon: Mail, label: 'Email', href: 'mailto:hello@sriayodhya.com', color: 'from-green-500 to-green-600' },
    { icon: MessageCircle, label: 'WhatsApp', href: 'https://wa.me/918041234567', color: 'from-emerald-500 to-emerald-600' },
  ]

  return (
    <div className="fixed bottom-8 right-8 z-40">
      <AnimatePresence>
        {isOpen && (
          <div className="absolute bottom-20 right-0 flex flex-col gap-4 mb-4">
            {actions.map((action, index) => (
              <motion.a
                key={action.label}
                href={action.href}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3"
              >
                <span className="text-sm font-semibold text-foreground bg-secondary rounded-lg px-3 py-2 whitespace-nowrap hidden sm:inline">
                  {action.label}
                </span>
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${action.color} flex items-center justify-center text-white shadow-lg hover:shadow-xl transition-shadow`}>
                  <action.icon size={24} />
                </div>
              </motion.a>
            ))}
          </div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-primary-foreground shadow-lg hover:shadow-xl transition-shadow"
      >
        {isOpen ? <X size={28} /> : <Phone size={28} />}
      </motion.button>
    </div>
  )
}
