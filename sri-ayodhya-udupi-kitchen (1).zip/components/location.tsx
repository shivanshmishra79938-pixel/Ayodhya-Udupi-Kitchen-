'use client'

import { motion } from 'framer-motion'
import { MapPin, Phone, Mail, Clock } from 'lucide-react'

export function Location() {
  return (
    <section id="location" className="py-20 px-4 sm:px-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mb-16"
      >
        <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-2">Find Us</p>
        <h2 className="font-serif text-4xl sm:text-5xl font-bold mb-4">Location & Hours</h2>
        <p className="text-muted-foreground max-w-2xl">
          Visit us at our elegant location in the heart of the city.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        {/* Info Cards */}
        <div className="space-y-6">
          {/* Address */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-xl"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="text-primary" size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-2">Address</h3>
                <p className="text-muted-foreground">
                  123 Krishna Lane, Bangalore<br />
                  Karnataka 560034, India
                </p>
                <a href="https://maps.google.com" className="text-primary hover:text-primary/80 text-sm mt-2 inline-block">
                  Get Directions →
                </a>
              </div>
            </div>
          </motion.div>

          {/* Phone */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-xl"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="text-primary" size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-2">Phone</h3>
                <a href="tel:+918041234567" className="text-muted-foreground hover:text-primary">
                  +91 8041234567
                </a>
                <p className="text-muted-foreground">
                  Available for reservations & inquiries
                </p>
              </div>
            </div>
          </motion.div>

          {/* Email */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-xl"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="text-primary" size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-2">Email</h3>
                <a href="mailto:hello@sriayodhya.com" className="text-muted-foreground hover:text-primary">
                  hello@sriayodhya.com
                </a>
                <p className="text-muted-foreground">
                  Response within 24 hours
                </p>
              </div>
            </div>
          </motion.div>

          {/* Hours */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
            className="glass p-8 rounded-xl"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <Clock className="text-primary" size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-2">Hours</h3>
                <p className="text-muted-foreground">
                  Mon - Thu: 11:00 AM - 10:00 PM<br />
                  Fri - Sat: 11:00 AM - 11:00 PM<br />
                  Sunday: 12:00 PM - 10:00 PM
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Map */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="rounded-xl overflow-hidden h-96 md:h-full min-h-96"
        >
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.5920773265843!2d77.5946!3d12.9716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1581c8e5555f%3A0x1234567890abcdef!2sKrishna%20Lane%2C%20Bangalore!5e0!3m2!1sen!2sin!4v1234567890123"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full h-full"
          />
        </motion.div>
      </div>
    </section>
  )
}
