import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Playfair_Display, Inter } from 'next/font/google'
import './globals.css'

const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' })
const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'Sri Ayodhya Udupi Kitchen | Premium Vegetarian South Indian Cuisine',
  description: 'Experience authentic South Indian and North Indian vegetarian cuisine at Sri Ayodhya Udupi Kitchen. 4.3★ rated restaurant with pure vegetarian delicacies.',
  generator: 'v0.app',
  openGraph: {
    title: 'Sri Ayodhya Udupi Kitchen',
    description: 'Premium vegetarian South Indian cuisine',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#d4af37',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${playfair.variable} ${inter.variable} antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
