'use client'

import { Header } from '@/components/header'
import { Hero } from '@/components/hero'
import { Menu } from '@/components/menu'
import { Gallery } from '@/components/gallery'
import { Reviews } from '@/components/reviews'
import { Stats } from '@/components/stats'
import { Location } from '@/components/location'
import { Contact } from '@/components/contact'
import { FloatingCTA } from '@/components/floating-cta'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <main className="bg-background text-foreground">
      <Header />
      <Hero />
      <Menu />
      <Gallery />
      <Reviews />
      <Stats />
      <Location />
      <Contact />
      <FloatingCTA />
      <Footer />
    </main>
  )
}
